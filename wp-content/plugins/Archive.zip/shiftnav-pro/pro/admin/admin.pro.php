<?php

require_once( 'settings.pro.php' );
require_once( 'item.settings.pro.php' );